# Toggle-coverage exclusions for large memory-like storage arrays.
#
# Toggling every bit of a 64 KB instruction memory or a 16K-word data memory
# is not a meaningful coverage goal - it would take an enormous amount of
# stimulus and doesn't tell you anything about untested LOGIC, only about
# untested memory CONTENTS. Excluding storage arrays from toggle coverage
# (while leaving statement/branch/condition coverage on them untouched) is
# standard practice. Source once per vsim session, right after the design is
# loaded and before `run -all`:
#     do scripts/coverage_exclusions.do
coverage exclude -du ins_mem      -togglenode mem
coverage exclude -du data_mem     -togglenode mem
coverage exclude -du vec_regfile  -togglenode vr
