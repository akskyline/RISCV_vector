#!/usr/bin/env python3
"""
Generates N random RV32I programs (scripts/gen_random.py) straight to hex/rand_<seed>.hex,
and writes hex/manifest_random.txt (same two-column format as hex/manifest.txt) so
scripts/run_coverage_modelsim.do can run them through the coverage regression too.
Random programs exercise far more operand/address bit patterns than the fixed
corner-value directed tests, which is exactly what raises toggle and condition
coverage the most.

    python3 scripts/gen_random_hex.py 20          # 20 programs, seeds 1..20, 300 items each
    python3 scripts/gen_random_hex.py 20 500 100   # count, length, starting seed
"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
import rv32_asm, gen_random

count  = int(sys.argv[1]) if len(sys.argv) > 1 else 20
length = int(sys.argv[2]) if len(sys.argv) > 2 else 300
seed0  = int(sys.argv[3]) if len(sys.argv) > 3 else 1

root = os.path.join(os.path.dirname(__file__), "..")
os.makedirs(os.path.join(root, "hex"), exist_ok=True)
lines = []
for seed in range(seed0, seed0 + count):
    name = f"rand_{seed}"
    src = gen_random.generate(seed, length)
    rv32_asm.write_hex(rv32_asm.assemble(src), os.path.join(root, "hex", f"{name}.hex"))
    lines.append(f"{name} 11")   # every generated program ends in ecall -> cause 11
with open(os.path.join(root, "hex", "manifest_random.txt"), "w") as f:
    f.write("\n".join(lines) + "\n")
print(f"wrote {count} programs to hex/rand_*.hex and hex/manifest_random.txt")
