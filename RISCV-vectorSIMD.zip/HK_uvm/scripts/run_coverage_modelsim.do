# Full-regression code coverage, merged into ONE database.
#
#     do scripts/run_coverage_modelsim.do
#
# WHY THIS EXISTS: a single small program (e.g. just soc/ins_little_endian.hex,
# ~30 instructions) can only ever exercise a sliver of the RTL - most opcodes,
# most trap causes, most vector commands, most address ranges simply never
# happen in one short run. Coverage from one run being low is expected, not a
# sign of a weak testbench. The fix is to run the WHOLE regression - every
# hex/*.hex program (34 of them), the coprocessor's 563-command scenario
# suite, and the SoC test - with coverage enabled on every single run, and
# MERGE all of those runs into one cumulative database before reporting.
# Coverage is a property of a regression, not of any one test.
#
# RTL is compiled instrumented (-cover); the testbenches are compiled plain -
# code coverage measures the DESIGN, not the checker, and the testbenches'
# own big reference-model memories (tb/rv32i_iss.sv) would otherwise pad out
# (and confuse) the numbers with nothing to do with the DUT.
#
# Output: coverage/merged.ucdb (the combined database) and
#         coverage/overall_coverage.txt (the report)
quit -sim
if {[file exists work]} { vdel -lib work -all }
vlib work
# -mfcu on both: without it, Questa's per-file compilation-unit default
# means only the first file in each list to `include rv32i_types.svh gets
# the rvfi_t typedef (the header's own `ifndef guard, not being unit-scoped,
# silently skips it for every file after that) - see scripts/run_modelsim.do
# for the full explanation.
vlog -mfcu -sv -cover bcestf +incdir+rtl rtl/*.sv
vlog -mfcu -sv +incdir+rtl tb/*.sv

file mkdir coverage
set ucdbs {}

set fd [open hex/manifest.txt r]
set lines [split [read $fd] "\n"]
close $fd
foreach line $lines {
    if {$line eq ""} continue
    lassign $line name cause
    set args [list +HEX=hex/$name.hex +QUIET]
    if {$cause ne "-"} { lappend args +EXPECT_CAUSE=$cause }
    vsim -onfinish stop -c -coverage work.rv32i_tb {*}$args
    do scripts/coverage_exclusions.do
    run -all
    coverage save coverage/$name.ucdb
    quit -sim
    lappend ucdbs coverage/$name.ucdb
}

# ---- random programs (hex/rand_*.hex + hex/manifest_random.txt), if present.
# Generate them first from an OS shell (not this Tcl console):
#     python3 scripts/gen_random_hex.py 20
# Random programs hit far more operand/address bit patterns than the fixed
# corner-value directed tests, and are usually the single biggest lever for
# raising toggle and condition coverage further. Safe to skip if you haven't
# generated any yet - this block just does nothing.
if {[file exists hex/manifest_random.txt]} {
    set fd [open hex/manifest_random.txt r]
    set rlines [split [read $fd] "\n"]
    close $fd
    foreach line $rlines {
        if {$line eq ""} continue
        lassign $line name cause
        set args [list +HEX=hex/$name.hex +QUIET]
        if {$cause ne "-"} { lappend args +EXPECT_CAUSE=$cause }
        vsim -onfinish stop -c -coverage work.rv32i_tb {*}$args
        do scripts/coverage_exclusions.do
        run -all
        coverage save coverage/$name.ucdb
        quit -sim
        lappend ucdbs coverage/$name.ucdb
    }
}

vsim -onfinish stop -c -coverage work.vec_coproc_tb
do scripts/coverage_exclusions.do
run -all
coverage save coverage/vec_coproc_tb.ucdb
quit -sim
lappend ucdbs coverage/vec_coproc_tb.ucdb

vsim -onfinish stop -c -coverage work.riscv_soc_tb +HEX=soc/ins_little_endian.hex
do scripts/coverage_exclusions.do
run -all
coverage save coverage/riscv_soc_tb.ucdb
quit -sim
lappend ucdbs coverage/riscv_soc_tb.ucdb

# ---- merge every run into one database, then report on THAT
eval vcover merge coverage/merged.ucdb $ucdbs
vcover report coverage/merged.ucdb -details -output coverage/overall_coverage.txt
vcover report coverage/merged.ucdb -summary
echo "==== merged [llength $ucdbs] runs -> coverage/merged.ucdb ===="
echo "==== full report: coverage/overall_coverage.txt   |   totals only: vcover report coverage/merged.ucdb -summary ===="
