# ModelSim regression.  From the project folder (the one that contains rtl/, tb/, hex/, soc/):
#     do scripts/run_modelsim.do
# Every hex/*.hex program is run through the lockstep testbench (DUT vs reference model); then the
# coprocessor unit test and the SoC test.  Look for  "RESULT PASS" / "TEST PASSED"  in the transcript.
quit -sim
if {[file exists work]} { vdel -lib work -all }
vlib work
# -mfcu: rtl/rv32i_types.svh (and vec_defs.svh) are `include headers with an
# `ifndef guard, and Questa defaults to a SEPARATE compilation unit per file,
# so without -mfcu only the first file to `include the header actually gets
# the rvfi_t typedef - every later file's `include is silently skipped
# because the guard macro (unlike the typedef itself) is not unit-scoped.
# -mfcu merges this whole file list into one shared unit so that's a non-issue.
vlog -mfcu -sv +incdir+rtl rtl/*.sv tb/*.sv

set fd [open hex/manifest.txt r]
set lines [split [read $fd] "\n"]
close $fd
set summary {}
foreach line $lines {
    if {$line eq ""} continue
    lassign $line name cause
    set args [list +HEX=hex/$name.hex +QUIET]
    if {$cause ne "-"} { lappend args +EXPECT_CAUSE=$cause }
    vsim -onfinish stop -c work.rv32i_tb {*}$args
    run -all
    quit -sim
}

vsim -onfinish stop -c work.vec_coproc_tb
run -all
quit -sim

vsim -onfinish stop -c work.riscv_soc_tb +HEX=soc/ins_little_endian.hex
run -all
quit -sim
echo "==== done: check the transcript for any FAIL / TEST FAILED ===="
