# Verification Report — RV32I Single-Cycle Core + Memory-Mapped Vector Coprocessor

This document covers the **Verification** and **Results** sections of the project. It describes two
verification tracks that exist side by side over the same RTL:

1. **Classic track** (`tb/`, `scripts/`) — SystemVerilog testbenches + a Python-based reference model /
   assembler / mutation-test framework. Runs today on any simulator, including the sandbox this repository
   was authored in (Icarus Verilog); its results below are real, reproduced numbers.
2. **UVM track** (`uvm/`) — a UVM-1.2 environment (agents, sequencer/driver/monitor, scoreboards,
   constrained-random sequences, functional coverage) layered over the same RTL and the same reference
   models, intended for ModelSim/Questa. **This environment has not been compiled or simulated by the
   author of this document** — no QuestaSim/ModelSim license and no network access to obtain one were
   available in the authoring environment. Every claim about the UVM track below is stated as such; where a
   number would normally go, you'll find instead exactly what command reproduces it once you run it in your
   own Questa install. This is the same honest-status convention the rest of this project already follows
   (see the header comments in `uvm/vec/vec_pkg.sv`, `uvm/core/core_pkg.sv`, and `uvm/README.md`).

---

## 1. Verification strategy

The core design decision behind this whole verification effort is **lockstep checking against an
independent reference model**, not a hand-written list of expected values per test:

* For the **RV32I core**, every retired instruction (tapped via an `rvfi`-style retire-trace port: PC,
  instruction word, register/memory reads and writes, trap/cause) is checked field-by-field against a
  from-scratch instruction-set simulator (`tb/rv32i_iss.sv`, restated as a plain class for the UVM
  scoreboard in `uvm/core/core_pkg.sv`'s `rv32i_reference_model`). Any RTL bug that changes architectural
  behaviour — not just a specific test's expected output — is caught the moment it retires, on *any*
  program, directed or random.
* For the **vector coprocessor**, every bus cycle and every reconstructed whole command (OP/VSEL/VL/START)
  is checked against a small behavioural model of the register file and ALU ops (`vec_scoreboard` in
  `uvm/vec/vec_pkg.sv`, mirroring the original `tb/vec_coproc_tb.sv`'s `model_exec`/`run_cmd`).
* For the **SoC**, both checkers run simultaneously and independently — the CPU's own lockstep check, plus
  the coprocessor's bus-level check watching the same internal bus the CPU (not a testbench driver) is
  mastering.

On top of lockstep checking, three more layers are combined, in increasing order of how much they lean on
randomness:

| Layer | What it catches | Where |
|---|---|---|
| **Directed / corner-case tests** | Known-tricky architectural corners: every trap cause, misaligned accesses, aliased operands, illegal opcodes, boundary VL, reset mid-operation | `tests/*.S` (core), `vec_directed_seq` + `vec_corner_sweep_seq` + `vec_negative_access_seq` (coprocessor) |
| **Constrained-random testing** | Anything a human wouldn't think to write by hand — register/operand/opcode combinations at scale | `scripts/gen_random.py` / `gen_random_hex.py` (core), `vec_random_seq` + `vec_cmd_txn::randomize()` (coprocessor, real UVM randomization) |
| **Cross-checking against a second, independent implementation** | Bugs that are *also* in the hand-written reference model (a lockstep check alone can't catch a bug both sides share) | `scripts/xcheck_unicorn.py` — every program also runs on Unicorn (QEMU's RV32 engine) and results are diffed |
| **Mutation testing** | "Are my checkers actually strict enough?" | `scripts/mutation_test.py` injects deliberate RTL bugs and confirms the regression suite fails |
| **Formal-adjacent invariants** | Structural properties that should hold on *every* cycle, not just at retirement (no X on live signals, PC always word-aligned, illegal instructions never have a side effect, BUSY/DONE/ERR protocol shape) | SVA, `uvm/assertions/core_assertions.sv` + `vec_assertions.sv`, `bind`-inserted into the RTL |

Coverage closure strategy (how "near 100%" is actually pursued, not just asked for): every functional
coverage bin is designed to be **reachable by construction** — illegal opcodes/VLs, corner operands (0, 1,
−1, INT_MAX, INT_MIN), operand aliasing, branch taken/not-taken, jump direction, and ERR-then-legal
recovery all have a dedicated sequence or program that exhaustively or deliberately hits them, rather than
relying on random luck. Where a coverage cross would contain a cell that is *architecturally impossible*
(e.g. `LUI`/`AUIPC`/`JAL` have no real `funct3` field, so a `opcode × funct3` cross would have unreachable
cells for those rows), `ignore_bins` explicitly exclude it — this is standard practice for turning "stuck at
94% forever for reasons that have nothing to do with test quality" into "100% is actually achievable and
means something."

---

## 2. Testbench architecture

```
                     ┌─────────────────────────────────────────────┐
                     │              riscv_soc_top (RTL)             │
                     │  ┌───────────┐        ┌───────────────────┐  │
                     │  │ rv32i_core │◄─bus──►│    vec_coproc     │  │
                     │  └─────┬─────┘        └─────────┬─────────┘  │
                     └────────┼────────────────────────┼────────────┘
                              │ rvfi (retire trace)      │ mmio bus (sel/we/addr/wdata/rdata)
                 ┌────────────▼───────────┐   ┌──────────▼───────────┐
                 │      core checker       │   │    coprocessor       │
                 │ (lockstep vs rv32i_iss) │   │  checker (lockstep    │
                 │                         │   │  vs behavioural model)│
                 └─────────────────────────┘   └───────────────────────┘
```

**Classic track** (`tb/`): each DUT gets a plain-SV testbench module that instantiates the DUT, generates
clock/reset, drives/loads programs via `$readmemh` (`+HEX=`/`+DHEX=` plusargs), and calls the reference
model as a task every retired instruction / bus cycle. `tb/rv32i_tb.sv` (core), `tb/riscv_soc_tb.sv` (SoC),
`tb/vec_coproc_tb.sv` (coprocessor unit test, the original T1–T12 directed+random scenario suite).

**UVM track** (`uvm/`), standard UVM-1.2 layering:

* `uvm/vec/` — `vec_if` (pin-level interface, `DRIVER`/`MONITOR`/`RESETTER` modports) →
  `vec_sequencer`/`vec_driver`/`vec_monitor` → `vec_agent` (active/passive switch) → `vec_scoreboard` +
  `vec_coverage` → `vec_env`. Sequences and tests described in section 4.
* `uvm/core/` — `rvfi_if` (retire-trace interface) → `core_monitor` (no driver: the core's stimulus is the
  program in instruction memory, not something a UVM driver produces) → `core_agent` → `core_scoreboard` +
  `core_coverage` → `core_env`.
* `uvm/soc/` — reuses both environments unmodified: `core_env` as-is, `vec_env` instantiated a second time
  with its agent forced `UVM_PASSIVE` (the CPU, not a UVM driver, is the real bus master inside the SoC).
* `uvm/assertions/` — plain SVA, `bind`-inserted into `rv32i_core` and `vec_coproc`; no UVM dependency, runs
  in any simulator.

---

## 3. Test scenarios

**Core / SoC** (`tests/*.S`, `hex/manifest.txt`, 34 directed programs today):

* All 40 RV32I base instructions exercised (R/I/L/S/B/U/J formats + FENCE/ECALL/EBREAK).
* All 6 trap causes: fetch-misaligned, illegal instruction, EBREAK, load-misaligned, store-misaligned,
  ECALL.
* Every misaligned-access flavour: `lh`/`lhu`/`sh` at odd addresses, `lw`/`sw` not word-aligned, taken
  branch / `jal` / `jalr` landing on an odd address.
* Illegal encodings: bad `funct3` on branch/load/store/shift, bad `funct7` on `slli`/`srai`/`sub`, illegal
  opcode, all-zero and all-ones instruction words, `mul` (illegal — base RV32I only), compressed encoding
  (illegal — no C extension), CSR access (illegal — no CSRs in base RV32I).
* Register-aliasing corners (`rd==rs1`, `rd==rs1==rs2`, `rd==x0`), ALU operand corners (0, 1, −1, INT_MAX,
  INT_MIN), branch taken/not-taken, jump forward/backward.
* 200+ randomly generated programs (`scripts/gen_random.py` / `gen_random_hex.py`), each also cross-checked
  against Unicorn.

**Vector coprocessor** (`tb/vec_coproc_tb.sv` T1–T12, ported/extended in `uvm/vec/vec_pkg.sv`):

* T1/T3 — basic directed vector add.
* T4 — every element-wise opcode (ADD/MUL/SLT/SEQ) × every VL (1–4) × corner operands.
* T5 — both reductions (REDSUM/REDMAX) × every VL.
* T6 — aliased operands (`vd==vs1`, `vd==vs2`, `vs1==vs2`).
* T7 — illegal commands: bad opcode, VL=0, VL>LANES.
* T8 — CLR after an ERR, then a legal command right after (recovery).
* T2/T10 — write-only/read-only register misuse, out-of-window bus accesses (`vec_negative_access_seq`).
* T9/T11 — reset asserted mid-command (`vec_reset_mid_op_test`, new — see section 4).
* T12 — weighted constrained-random commands, ~20% illegal by construction (`vec_random_seq`, now via real
  `vec_cmd_txn::randomize()`, and `vec_corner_sweep_seq`, new — an exhaustive `op(0–15) × vl(0–7)` sweep so
  every illegal-op/illegal-VL/legal-cross bin is hit deterministically rather than by random luck).

---

## 4. UVM architecture, agents, sequences, scoreboard, assertions, functional coverage, code coverage

*(This is the "Verification Track" checklist item — everything below lives under `uvm/`.)*

**Agents**

| Agent | Component | Active/Passive |
|---|---|---|
| `vec_agent` (standalone coprocessor test) | sequencer + driver + monitor | Active |
| `vec_agent` (inside `soc_env`) | monitor only | Passive (`is_active` forced via `uvm_config_db`) |
| `core_agent` | monitor only (no driver — see strategy above) | Passive by construction |

**Sequences** (`vec_bus_item`/`vec_cmd_txn` sequence items, all `uvm_sequence #(vec_bus_item)` subclasses):

* `vec_directed_seq` — T1/T3–T8/T10.
* `vec_corner_sweep_seq` — **new**: exhaustive `op × vl` sweep (128 commands), `txn.randomize() with {
  op == local::op; vl == local::vl; }` pins the two swept fields while everything else (operands, register
  indices, aliasing) still randomizes.
* `vec_negative_access_seq` — **new**: T2/T10 write-only/read-only/out-of-window accesses.
* `vec_random_seq` — T12, rewritten to use `vec_cmd_txn::randomize()` (weighted `dist` constraints on
  op/VL, corner-biased operand `dist`, aliasing forced through implication constraints) instead of manual
  `$urandom_range` picking. This is the piece that directly answers "use UVM functions like randomize."
* `vec_reset_mid_op_test` (a test, not a sequence, since it needs to drive reset itself — see below) — T9/T11.
* `vec_cov_test` — **new**: runs directed + sweep + negative + random + reset back-to-back in one `vsim`
  invocation, the one to point at for a single coverage-closure regression.

**Scoreboards** — `core_scoreboard` (lockstep vs `rv32i_reference_model`, checks every `rvfi` field of every
retired instruction), `vec_scoreboard` (lockstep vs a behavioural vector-register/ALU model, plus a
BUSY→DONE/ERR protocol-state checker).

**Assertions** — `uvm/assertions/core_assertions.sv` (reset behaviour, no-X-when-live, PC alignment,
illegal-instruction side-effect freedom, trap/halt latching) and `vec_assertions.sv` (BUSY/DONE/ERR
protocol shape), both plain SVA `bind`-inserted into the RTL, independent of the UVM class library.

**Functional coverage** — `core_coverage` (`cg_insn`: opcode × funct3 [with `ignore_bins` excluding
opcodes with no real funct3 field], ALU operand corners on both operands, `rd==rs1`, `rs1==rs2`, `rd==x0`,
trap/cause, branch taken/not-taken × funct3, jump direction) and `vec_coverage` (`cg_cmd`: op × VL [legal
and illegal, separately gated], aliasing; `cg_recover`: legal-after-illegal / illegal-after-legal transition
coverage — the "an ERR doesn't stick" property). See `uvm/README.md` for the full bin list and the
reasoning behind each `ignore_bins`.

**Code coverage** — RTL compiled with `-cover bcestf` (branch/condition/expression/statement/toggle/FSM);
`scripts/coverage_exclusions.do` excludes large memory arrays from toggle coverage (standard practice —
toggling every bit of a 64 KB instruction memory measures test *content*, not untested *logic*).
`uvm/run_uvm_modelsim.do` saves one `.ucdb` per test and merges everything into
`uvm/coverage/merged_uvm.ucdb` / `uvm/coverage/overall_uvm_coverage.txt`.

**The one thing UVM sequences can't drive directly**: reset. `vec_reset_mid_op_test` needed to assert reset
*in the middle of* an in-flight command, which a `uvm_sequence_item` can't express (reset isn't a bus
cycle). Solved with a small, deliberately narrow addition to `vec_if`: an `inject_reset` signal and a new
`RESETTER` modport, OR'd into the DUT's actual reset only in the standalone coprocessor testbench
(`vec_coproc_uvm_tb.sv`). Defaults low, so every other test is completely unaffected — this is called out
explicitly here because it's the one place the environment does something a textbook UVM agent wouldn't.

---

## 5. Assertions / scoreboard detail

See `uvm/assertions/core_assertions.sv` and `vec_assertions.sv` for the full property list; the ones that
matter most for coverage closure and bug-catching power:

* `a_illegal_no_regwrite` / `a_illegal_no_memwrite` — an illegal instruction must never have a side effect,
  checked at the *decoder* signal level (`regwrite_c`/`memwrite_c`), independent of the trap unit that
  gates them — catches a bug in either the decoder or the trap unit.
* `a_pc_word_aligned`, `a_pc_zero_on_reset`, `a_no_x_pc`/`a_no_x_instruction` — structural invariants that
  hold every cycle, not just at retirement.
* Vector coprocessor: STATUS must read `BUSY` (and only `BUSY`) exactly once right after `START` for a
  legal command, then `DONE` (`DONE|ERR` for illegal) — checked both in SVA and independently again in
  `vec_scoreboard`'s state machine (`IDLE`/`EXPECT_BUSY`/`EXPECT_DONE`), so a timing bug has to slip past
  two independently-written checkers to go unnoticed.

The scoreboards themselves (`core_scoreboard`, `vec_scoreboard`) are described under section 1/4 above —
field-by-field lockstep checking is the core mechanism, not a supplementary one.

---

## 6. Results

### 6.1 Simulation results — classic track (real, reproduced in this environment)

Run with: `python3 scripts/regress.py --random 50 --xcheck` (Icarus Verilog; the coverage snapshot in
`coverage/overall_coverage.txt` in this repo was produced the same way, plus `do
scripts/run_coverage_modelsim.do` in ModelSim for code coverage). Per the top-level `README.md`'s existing
"Verification done" section: all 34 directed/trap programs + 200+ random programs pass lockstep and
Unicorn cross-check; 33/33 injected mutation-test bugs detected; all 40 RV32I instructions and all 6 trap
causes exercised.

### 6.2 Simulation / pass-fail results — UVM track

**Not available from this authoring environment** — no QuestaSim/ModelSim, no network access to obtain one.
Run `do uvm/run_uvm_modelsim.do` (see `uvm/README.md`) and every test prints `*** TEST PASSED ***` or
`*** TEST FAILED *** (N errors)` from its `report_phase`; grep the transcript for `UVM_ERROR`/`UVM_FATAL`
for anything the pass/fail summary line doesn't already surface.

### 6.3 Coverage results — UVM track

**Not available from this authoring environment**, same reason. After `do uvm/run_uvm_modelsim.do`:

* Functional coverage — grep the transcript for `_COV` (`CORE_COV`, `VEC_COV`); each package's
  `report_phase` prints `cg_insn`/`cg_cmd`/`cg_recover`'s `get_coverage()` percentage directly.
* Code coverage — `uvm/coverage/overall_uvm_coverage.txt` (detailed) or `vcover report
  uvm/coverage/merged_uvm.ucdb -summary` (totals only).

If either comes back below ~100% on first run, the fastest way to close the gap (in order of leverage):
1. Check whether the missing bin is one `ignore_bins` should have excluded but doesn't yet (architecturally
   unreachable combination) — add the exclusion rather than chasing an impossible bin.
2. Bump `vec_random_seq`'s `N_CMDS` (`+N_CMDS=<n>`, default 400) — most remaining gaps in `cg_cmd` are rare
   `dist`-weighted corners that just need more samples.
3. For `cg_insn` gaps tied to a specific opcode/funct3/cause combination, the fastest fix is usually a small
   new `tests/*.S` program targeting exactly that combination (see the existing `tests/trap_*.S` for the
   pattern) — much cheaper than trying to coax a random generator into a specific rare corner.

---

## 7. What to send back

This project has, so far, been built by an iterative "write code → compile/run in your ModelSim → paste
back the output → fix" loop (see the git-blame-style history in the header comments throughout `uvm/`).
The single most useful next message is the output of:
```tcl
do uvm/run_uvm_modelsim.do
```
— the transcript (pass/fail lines, any `UVM_ERROR`, the `_COV` percentage lines) and
`uvm/coverage/overall_uvm_coverage.txt`. Any compile errors on first attempt are expected and will be fixed
the same way every other file in this project was.
