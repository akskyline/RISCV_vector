# pins.tcl - pin assignment for riscv_soc_top (395 outputs + clk/rst = 397 pins).
# The lab uses read_io_file pins.io; this script places the pins once and then
# writes pins.io so later runs can simply do:  read_io_file pins.io
set all_out   [get_db [get_db ports -if {.direction == out}] .name]
set rvfi_pins [lsearch -all -inline $all_out rvfi*]
set stat_pins [lsearch -all -inline -not $all_out rvfi*]
set half      [expr {[llength $rvfi_pins] / 2}]

set_db assign_pins_edit_in_batch true
edit_pin -pin {clk rst}   -side Left   -layer Metal3 -spread_type center -spacing 5 -unit micron -fix_overlap 1
edit_pin -pin $stat_pins  -side Left   -layer Metal3 -spread_type side   -fix_overlap 1
edit_pin -pin [lrange $rvfi_pins 0 [expr {$half-1}]] -side Top   -layer Metal4 -spread_type side -fix_overlap 1
edit_pin -pin [lrange $rvfi_pins $half end]          -side Right -layer Metal3 -spread_type side -fix_overlap 1
set_db assign_pins_edit_in_batch false
write_io_file pins.io
