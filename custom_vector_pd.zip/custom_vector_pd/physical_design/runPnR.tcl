# =============================================================================
# runPnR.tcl - Module 3: complete implementation of riscv_soc_top (Innovus Stylus)
#   cd physical_design ; innovus -stylus -files runPnR.tcl
# Every step matches a section of the lab manual; a write_db checkpoint after
# each lets you stop, inspect in the GUI (gui_show) and continue by hand.
# =============================================================================

#---------------------------------------------------------------- Importing the Design
set_db init_power_nets  VDD
set_db init_ground_nets VSS
read_mmmc riscv.view
read_physical -lef {../lef/gsclib045_tech.lef ../lef/gsclib045_macro.lef}
read_netlist ../synthesis/outputs/riscv_soc_top_netlist.v -top riscv_soc_top
init_design

connect_global_net VDD -type pg_pin -pin_base_name VDD -inst_base_name *
connect_global_net VSS -type pg_pin -pin_base_name VSS -inst_base_name *
catch { check_design -type all > reports/01_check_design.rpt }

#---------------------------------------------------------------- Floorplanning the Design
# aspect 1, core utilization 0.6, core-to-die margin 10 um (room for 2 um rings)
create_floorplan -core_margins_by die -site CoreSite -core_density_size 1 0.6 10 10 10 10

#---------------------------------------------------------------- Pin Assignment
if {[file exists pins.io]} { read_io_file pins.io } else { source pins.tcl }

#---------------------------------------------------------------- Power Planning: rings
set_db add_rings_skip_shared_inner_ring none
set_db add_rings_avoid_short 1
set_db add_rings_ignore_rows 0
set_db add_rings_extend_over_row 0
add_rings -type core_rings -jog_distance 0.6 -threshold 0.6 -nets {VDD VSS} -follow core \
          -layer {bottom Metal11 top Metal11 right Metal10 left Metal10} \
          -width 2 -spacing 1 -offset 1

#---------------------------------------------------------------- Power Planning: stripes
add_stripes -block_ring_top_layer_limit Metal11 -max_same_layer_jog_length 0.44 \
            -pad_core_ring_bottom_layer_limit Metal9 -set_to_set_distance 30 \
            -pad_core_ring_top_layer_limit Metal11 -spacing 1 -merge_stripes_value 0.6 \
            -layer Metal10 -block_ring_bottom_layer_limit Metal9 -width 1.5 \
            -start_from left -start_offset 10 -nets {VDD VSS}

#---------------------------------------------------------------- Special Route (followpins)
route_special -connect core_pin -layer_change_range { Metal1(1) Metal11(11) } \
              -block_pin_target nearest_target -core_pin_target first_after_row_end \
              -allow_jogging 1 -crossover_via_layer_range { Metal1(1) Metal11(11) } \
              -nets { VDD VSS } -allow_layer_change 1 \
              -target_via_layer_range { Metal1(1) Metal11(11) }

catch { check_connectivity -type special -out_file reports/02_pg_connectivity.rpt }
write_db floorplan

#---------------------------------------------------------------- Placement Optimization
# (no scan DEF: this design has no DFT, so read_def *.scandef is skipped)
place_opt_design -report_dir reports/placeOpt
set_db add_tieoffs_cells {TIEHI TIELO}
add_tieoffs
time_design -pre_cts -report_dir reports/timing_preCTS
catch { report_congestion -hotspot > reports/03_congestion_place.rpt }
write_db placeOpt

#---------------------------------------------------------------- Clock Tree Synthesis
create_clock_tree_spec
clock_opt_design -report_dir reports/cts
opt_design -post_cts -hold -report_dir reports/postCTS_hold
time_design -post_cts        -report_dir reports/timing_postCTS
time_design -post_cts -hold  -report_dir reports/timing_postCTS_hold
catch { report_clock_trees  -out_file reports/04_clock_trees.rpt }
catch { report_skew_groups  -out_file reports/04_skew_groups.rpt }
write_db postCTSopt

#---------------------------------------------------------------- Routing the Nets
set_db route_design_with_timing_driven true
set_db route_design_with_si_driven     true
route_design -global_detail
set_db timing_analysis_type ocv
opt_design -post_route -setup -hold -report_dir reports/postRoute_opt
write_db postRoute

#---------------------------------------------------------------- Extraction and Timing Analysis
set_db extract_rc_engine post_route
extract_rc
write_parasitics -spef_file outputs/riscv_soc_top.spef -rc_corner rccorners
time_design -post_route        -report_dir reports/timing_postRoute
time_design -post_route -hold  -report_dir reports/timing_postRoute_hold
report_timing -late  -max_paths 20 > reports/05_setup_top20.rpt
report_timing -early -max_paths 20 > reports/05_hold_top20.rpt

#---------------------------------------------------------------- Filler Cell Placement
set_db add_fillers_cells {FILL64 FILL32 FILL16 FILL8 FILL4 FILL2 FILL1}
add_fillers -prefix FILLER

#---------------------------------------------------------------- Physical Verification
check_drc          -out_file reports/06_drc.rpt
check_connectivity -type all -out_file reports/06_connectivity.rpt
catch { check_process_antenna -out_file reports/06_antenna.rpt }

#---------------------------------------------------------------- Area / Congestion reports
catch { report_area                        > reports/07_area.rpt }
catch { report_congestion -hotspot         > reports/07_congestion_final.rpt }
catch { check_floorplan -report_density    > reports/07_density.rpt }

#---------------------------------------------------------------- Outputs
write_netlist outputs/riscv_soc_top_pnr.v
write_def     outputs/riscv_soc_top.def
catch { write_sdf     outputs/riscv_soc_top_pnr.sdf }
write_db riscv_soc_top.inn -lib
write_db -rc_extract -def postRoute_final
# Power analysis, rail (IR-drop) analysis and GDS export are done from the GUI
# exactly as in the manual - see GUIDE.md, Steps 3.13-3.15.
