add_search_path ../lib/ -library -both
read_library -liberty -both \
    /home/PD5/riscv_pd/custom_vector_pd/synthesis/../lib/slow_vdd1v0_basicCells.lib

