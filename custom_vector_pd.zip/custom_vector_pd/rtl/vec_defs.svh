`ifndef VEC_DEFS_SVH
`define VEC_DEFS_SVH
// =============================================================================
// vec_defs.svh - register map and opcodes of vec_coproc / vec_alu
// Textual include (like rv32i_types.svh) with its OWN include guard.
//
// Byte offsets inside the 2 KB coprocessor window (COPROC_BASE = 0x4000_0000):
//   0x000 CTRL    W : bit0 START, bit1 CLEAR (reads 0)
//   0x004 STATUS  R : bit0 BUSY, bit1 DONE, bit2 ERR
//   0x008 OP      RW: opcode (below)
//   0x00C VSEL    RW: [2:0] vd, [5:3] vs1, [8:6] vs2
//   0x010 VL      RW: active elements, 1..LANES
//   0x014 RESULT  R : scalar result of REDSUM / REDMAX
//   0x100-0x17F   RW: vector-register window, element e of v[r] at
//                     0x100 + (r*LANES + e)*4   (8 regs x 4 lanes x 32 bit)
// =============================================================================

// ---- register offsets (11-bit byte offsets, compared against addr[10:0]) ----
`define VREG_CTRL    11'h000
`define VREG_STATUS  11'h004
`define VREG_OP      11'h008
`define VREG_VSEL    11'h00C
`define VREG_VL      11'h010
`define VREG_RESULT  11'h014
`define VREG_WINDOW  11'h100      // window base -> word index 64

// ---- vector opcodes (4 bit) ------------------------------------------------
`define VOP_ADD      4'd0         // vd[i] = vs1[i] + vs2[i]
`define VOP_MUL      4'd1         // vd[i] = low 32 bits of vs1[i] * vs2[i]
`define VOP_SLT      4'd2         // vd[i] = (signed vs1[i] < vs2[i])
`define VOP_SEQ      4'd3         // vd[i] = (vs1[i] == vs2[i])
`define VOP_REDSUM   4'd4         // RESULT = sum of vs1[0..VL-1]
`define VOP_REDMAX   4'd5         // RESULT = signed max of vs1[0..VL-1]
`define VOP_MAX      4'd5         // highest legal opcode (op_ok check)

`endif
