// Synthesis file list (order matters only for readability; includes via +incdir)
+incdir+../rtl
../rtl/rv32i_core_modules.sv
../rtl/vec_alu.sv
../rtl/vec_regfile.sv
../rtl/vec_coproc.sv
../rtl_pd/pd_imem_rom.sv
../rtl_pd/pd_data_mem_flops.sv
../rtl/riscv_soc_top.sv
