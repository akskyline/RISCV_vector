# =============================================================================
# tempus_script.tcl - Module 4: independent sign-off STA (Tempus, Stylus UI)
#   cd STA ; tempus -stylus -files tempus_script.tcl
# Loads the final Innovus database (write_db -rc_extract -def postRoute_final).
# =============================================================================
read_db -physical_data ../physical_design/postRoute_final
set_db timing_analysis_type ocv

report_analysis_coverage          > reports/analysis_coverage.rpt
report_constraint -all_violators  > reports/all_violators.rpt
report_timing -late  -max_paths 50 > reports/setup.rpt
report_timing -early -max_paths 50 > reports/hold.rpt
# For interactive debug / ECO: gui_show, then Timing - Debug Timing (manual Lab 4-1)
