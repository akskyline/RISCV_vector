// Lab 2-2: make a Verilog model of the std-cell library for LEC (run once)
//   cd Equivalence_checking ; lec -XL -nogui -64 -dofile lib_v.do
set log file lib_v.log -replace
read library ../lib/slow_vdd1v0_basicCells.lib -liberty -both
write library ../lib/slow_vdd1v0_basicCells.v -verilog -replace
exit
