#!/bin/bash
# collect_results.sh - headline numbers into final_submission/PD_RESULTS.txt
cd "$(dirname "$0")/.."
R=physical_design/reports; O=final_submission/PD_RESULTS.txt
{
echo "==== riscv_soc_top - PD results ($(date)) ===="
echo; echo "--- Synthesis area ---";   sed -n '1,25p' synthesis/reports/report_area.rpt 2>/dev/null
echo; echo "--- Synthesis timing ---"; grep -m2 -i slack synthesis/reports/report_timing.rpt 2>/dev/null
echo; echo "--- Post-route setup ---"; grep -A10 -i "time_design Summary" $R/timing_postRoute/*.summary* 2>/dev/null | head -14
echo; echo "--- Post-route hold ---";  grep -A10 -i "time_design Summary" $R/timing_postRoute_hold/*.summary* 2>/dev/null | head -14
echo; echo "--- Final area ---";       sed -n '1,20p' $R/07_area.rpt 2>/dev/null
echo; echo "--- Density ---";          cat $R/07_density.rpt 2>/dev/null | head -10
echo; echo "--- Congestion ---";       cat $R/07_congestion_final.rpt 2>/dev/null | head -15
echo; echo "--- DRC ---";              tail -4 $R/06_drc.rpt 2>/dev/null
echo; echo "--- Connectivity ---";     tail -4 $R/06_connectivity.rpt 2>/dev/null
echo; echo "--- Antenna ---";          tail -4 $R/06_antenna.rpt 2>/dev/null
echo; echo "--- Power (GUI run1) ---"; grep -iE "Total (Internal|Switching|Leakage)? ?Power" physical_design/run1/*.rpt 2>/dev/null
echo; echo "--- LEC ---";              grep -iE "Equivalent|Non-equiv" Equivalence_checking/*.log 2>/dev/null | tail -6
echo; echo "--- Tempus ---";           head -30 STA/reports/analysis_coverage.rpt 2>/dev/null
} > $O
cp synthesis/outputs/*.v physical_design/outputs/* final_submission/ 2>/dev/null
cp physical_design/*.gds final_submission/ 2>/dev/null
echo "wrote $O"
