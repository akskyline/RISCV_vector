#!/usr/bin/env python3
"""
make_sample_program.py - writes tb/pd_sample_prog.hex, a small program that uses
EVERY RV32I instruction the core implements (so synthesis keeps all decode/ALU
logic when the ROM is built from it) plus coprocessor-window loads/stores.
Ends with ECALL (core traps and halts).

Replace with your real test program if you have one that also covers the ISA:
    python3 scripts/gen_imem_rom.py <your.hex>
"""
import os

def r(f7, rs2, rs1, f3, rd, op=0x33): return f7 << 25 | rs2 << 20 | rs1 << 15 | f3 << 12 | rd << 7 | op
def i(imm, rs1, f3, rd, op=0x13):     return (imm & 0xFFF) << 20 | rs1 << 15 | f3 << 12 | rd << 7 | op
def s(imm, rs2, rs1, f3):
    imm &= 0xFFF
    return (imm >> 5) << 25 | rs2 << 20 | rs1 << 15 | f3 << 12 | (imm & 0x1F) << 7 | 0x23
def b(imm, rs2, rs1, f3):
    imm &= 0x1FFF
    return ((imm >> 12) & 1) << 31 | ((imm >> 5) & 0x3F) << 25 | rs2 << 20 | rs1 << 15 | f3 << 12 \
         | ((imm >> 1) & 0xF) << 8 | ((imm >> 11) & 1) << 7 | 0x63
def u(imm20, rd, op): return (imm20 & 0xFFFFF) << 12 | rd << 7 | op
def j(imm, rd):
    imm &= 0x1FFFFF
    return ((imm >> 20) & 1) << 31 | ((imm >> 1) & 0x3FF) << 21 | ((imm >> 11) & 1) << 20 \
         | ((imm >> 12) & 0xFF) << 12 | rd << 7 | 0x6F

P = [
    u(0x12345, 1, 0x37),          # lui   x1, 0x12345
    u(0x00001, 2, 0x17),          # auipc x2, 1
    i(-7, 0, 0, 3),               # addi  x3, x0, -7
    i(5, 0, 0, 4),                # addi  x4, x0, 5
    i(3, 3, 2, 5),                # slti
    i(3, 3, 3, 6),                # sltiu
    i(0x0F, 4, 4, 7),             # xori
    i(0x30, 4, 6, 8),             # ori
    i(0x06, 4, 7, 9),             # andi
    i(4, 4, 1, 10),               # slli
    i(1, 3, 5, 11),               # srli
    i(0x400 | 1, 3, 5, 12),       # srai
    r(0, 4, 3, 0, 13),            # add
    r(0x20, 4, 3, 0, 14),         # sub
    r(0, 4, 3, 1, 15),            # sll
    r(0, 4, 3, 2, 16),            # slt
    r(0, 4, 3, 3, 17),            # sltu
    r(0, 4, 3, 4, 18),            # xor
    r(0, 4, 3, 5, 19),            # srl
    r(0x20, 4, 3, 5, 20),         # sra
    r(0, 4, 3, 6, 21),            # or
    r(0, 4, 3, 7, 22),            # and
    i(0x100, 0, 0, 23),           # addi x23, x0, 0x100  (data base)
    s(0, 1, 23, 2),               # sw  x1, 0(x23)
    s(4, 3, 23, 1),               # sh  x3, 4(x23)
    s(7, 4, 23, 0),               # sb  x4, 7(x23)
    i(0, 23, 2, 24, 0x03),        # lw
    i(4, 23, 1, 25, 0x03),        # lh
    i(7, 23, 0, 26, 0x03),        # lb
    i(4, 23, 5, 27, 0x03),        # lhu
    i(7, 23, 4, 28, 0x03),        # lbu
    u(0x40000, 10, 0x37),         # lui x10, 0x40000     (coprocessor base)
    s(0x100, 1, 10, 2),           # sw  x1, 0x100(x10)   (window / config)
    i(0x100, 10, 2, 29, 0x03),    # lw  x29, 0x100(x10)
    s(0, 4, 10, 2),               # sw  x4, 0(x10)
    i(4, 10, 2, 30, 0x03),        # lw  x30, 4(x10)
    b(8, 4, 4, 0),                # beq  (taken, skip 1)
    i(1, 0, 0, 31),               #   (skipped)
    b(8, 3, 4, 1),                # bne  (taken)
    i(1, 0, 0, 31),
    b(8, 4, 3, 4),                # blt  (taken)
    i(1, 0, 0, 31),
    b(8, 3, 4, 5),                # bge  (taken)
    i(1, 0, 0, 31),
    b(8, 3, 4, 6),                # bltu (taken: 5 < 0xFFFFFFF9)
    i(1, 0, 0, 31),
    b(8, 4, 3, 7),                # bgeu (taken)
    i(1, 0, 0, 31),
    j(8, 1),                      # jal  x1, +8
    i(1, 0, 0, 31),
    u(0, 5, 0x17),                # auipc x5, 0
    i(16, 5, 0, 6, 0x67),         # jalr x6, 16(x5)  -> skip next 2
    i(1, 0, 0, 31),
    i(1, 0, 0, 31),
    0x00000073,                   # ecall -> trap + halt
    0x00100073,                   # ebreak (decoded, never reached)
]

here = os.path.dirname(os.path.abspath(__file__))
out = os.path.join(here, "..", "tb", "pd_sample_prog.hex")
with open(out, "w") as f:
    for w in P:
        for k in range(4):
            f.write(f"{(w >> 8*k) & 0xFF:02x}\n")
print(f"wrote {os.path.normpath(out)}: {len(P)} instructions")
