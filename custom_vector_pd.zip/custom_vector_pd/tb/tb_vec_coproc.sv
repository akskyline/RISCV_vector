// =============================================================================
// tb_vec_coproc.sv - self-checking directed test of vec_coproc over its bus
// (register map from vec_defs.svh). Prints PASS/FAIL per check + summary.
// =============================================================================
`timescale 1ns/1ps
`include "vec_defs.svh"
module tb_vec_coproc;
    localparam int LANES = 4, NVREG = 8;
    logic clk = 0, rst = 1, sel = 0, we = 0;
    logic [10:0] addr = 0;
    logic [31:0] wdata = 0, rdata;
    int pass = 0, fail = 0;

    vec_coproc dut (.clk, .rst, .sel, .we, .addr, .wdata, .rdata);
    always #5 clk = ~clk;

    task automatic wr(input logic [10:0] a, input logic [31:0] d);
        @(negedge clk); sel = 1; we = 1; addr = a; wdata = d;
        @(negedge clk); sel = 0; we = 0;
    endtask
    task automatic rd(input logic [10:0] a, output logic [31:0] d);
        @(negedge clk); sel = 1; we = 0; addr = a; #1 d = rdata; sel = 0;
    endtask
    function automatic logic [10:0] el(input int r, input int e);
        return `VREG_WINDOW + 11'((r*LANES + e)*4);
    endfunction
    task automatic check(input string what, input logic [31:0] got, exp);
        if (got === exp) pass++; else begin fail++; $display("FAIL %s: got %h exp %h", what, got, exp); end
    endtask
    task automatic run(input int op, vd, vs1, vs2, vl);
        logic [31:0] s;
        wr(`VREG_OP, op); wr(`VREG_VSEL, vd | vs1<<3 | vs2<<6); wr(`VREG_VL, vl);
        wr(`VREG_CTRL, 32'h1);
        repeat (2) @(negedge clk);
        rd(`VREG_STATUS, s);
    endtask

    logic [31:0] a [4];   // 5, -2, 7, INT_MIN
    logic [31:0] b [4];
    logic [31:0] d, s;
    int e;

    initial begin
        a[0]=32'd5; a[1]=32'hFFFFFFFE; a[2]=32'd7; a[3]=32'h80000000;
        b[0]=32'd3; b[1]=32'd4;       b[2]=32'd7; b[3]=32'd1;
        #12 rst = 0;
        // reset state
        rd(`VREG_STATUS, d); check("reset STATUS", d, 0);
        rd(el(3,2), d);      check("reset vreg",   d, 0);
        // load v1 = a, v2 = b, window readback
        for (e = 0; e < 4; e++) begin wr(el(1,e), a[e]); wr(el(2,e), b[e]); end
        for (e = 0; e < 4; e++) begin rd(el(1,e), d); check("window rd", d, a[e]); end
        // config readback
        wr(`VREG_OP, 1); rd(`VREG_OP, d); check("OP rd", d, 1);
        wr(`VREG_VSEL, 3 | 1<<3 | 2<<6); rd(`VREG_VSEL, d); check("VSEL rd", d, 32'h8B);
        wr(`VREG_VL, 4); rd(`VREG_VL, d); check("VL rd", d, 4);

        // VADD full length -> v3
        run(`VOP_ADD, 3, 1, 2, 4);
        rd(`VREG_STATUS, s); check("ADD status DONE", s, 32'b010);
        for (e = 0; e < 4; e++) begin rd(el(3,e), d); check("VADD", d, a[e] + b[e]); end
        // VMUL -> v4
        run(`VOP_MUL, 4, 1, 2, 4);
        for (e = 0; e < 4; e++) begin rd(el(4,e), d); check("VMUL", d, a[e] * b[e]); end
        // VSLT (signed) -> v5
        run(`VOP_SLT, 5, 1, 2, 4);
        for (e = 0; e < 4; e++) begin rd(el(5,e), d); check("VSLT", d, ($signed(a[e]) < $signed(b[e])) ? 1 : 0); end
        // VSEQ -> v6
        run(`VOP_SEQ, 6, 1, 2, 4);
        for (e = 0; e < 4; e++) begin rd(el(6,e), d); check("VSEQ", d, (a[e] == b[e]) ? 1 : 0); end
        // VL masking: VADD with VL=2 into v7 preloaded with sentinel
        for (e = 0; e < 4; e++) wr(el(7,e), 32'hDEADBEEF);
        run(`VOP_ADD, 7, 1, 2, 2);
        for (e = 0; e < 4; e++) begin rd(el(7,e), d); check("VL mask", d, (e < 2) ? a[e] + b[e] : 32'hDEADBEEF); end
        // reductions
        run(`VOP_REDSUM, 0, 1, 0, 3); rd(`VREG_RESULT, d); check("REDSUM vl3", d, a[0]+a[1]+a[2]);
        run(`VOP_REDMAX, 0, 1, 0, 4); rd(`VREG_RESULT, d); check("REDMAX vl4", d, 32'd7);
        run(`VOP_REDMAX, 0, 1, 0, 2); rd(`VREG_RESULT, d); check("REDMAX vl2", d, 32'd5);
        // errors: illegal op, VL = 0, VL > LANES
        run(6, 3, 1, 2, 4);          rd(`VREG_STATUS, s); check("ERR bad op", s, 32'b110);
        run(`VOP_ADD, 3, 1, 2, 0);   rd(`VREG_STATUS, s); check("ERR VL=0",   s, 32'b110);
        run(`VOP_ADD, 3, 1, 2, 5);   rd(`VREG_STATUS, s); check("ERR VL=5",   s, 32'b110);
        rd(el(3,0), d);              check("no write on ERR", d, a[0] + b[0]);
        // CLEAR
        wr(`VREG_CTRL, 32'h2); rd(`VREG_STATUS, s); check("CLEAR", s, 0);
        // BUSY: status sampled in the EXEC cycle, config write during BUSY ignored
        wr(`VREG_OP, `VOP_ADD); wr(`VREG_VSEL, 3 | 1<<3 | 2<<6); wr(`VREG_VL, 4);
        @(negedge clk); sel = 1; we = 1; addr = `VREG_CTRL; wdata = 1;
        @(negedge clk); we = 0; addr = `VREG_STATUS; #1 check("BUSY", rdata, 32'b001);
        we = 1; addr = `VREG_OP; wdata = `VOP_MUL;              // write while busy
        @(negedge clk); sel = 0; we = 0;
        rd(`VREG_OP, d); check("OP locked while BUSY", d, `VOP_ADD);
        rd(`VREG_STATUS, s); check("DONE after BUSY", s, 32'b010);
        // unmapped read
        rd(11'h7FC, d); check("unmapped reads 0", d, 0);

        $display("vec_coproc: %0d passed, %0d failed", pass, fail);
        if (fail) $display("RESULT: FAIL"); else $display("RESULT: PASS");
        $finish;
    end
endmodule
