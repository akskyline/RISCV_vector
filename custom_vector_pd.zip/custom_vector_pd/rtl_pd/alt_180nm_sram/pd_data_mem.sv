// =============================================================================
// pd_data_mem.sv - PHYSICAL-DESIGN view of `data_mem` (replaces the behavioural
// model in rtl/rv32i_memories.sv for synthesis / PnR ONLY; the original file is
// untouched and still used for RTL simulation).
//
// Same module name and ports as the behavioural model, so rtl/riscv_soc_top.sv
// is read unchanged.
//
// Implementation: 1 KB (256 words x 32 bit) built from FOUR ram_256x16A macros,
// one per byte lane (only D[7:0]/Q[7:0] of each macro are used). One macro per
// lane gives exact sb/sh/sw byte-enable behaviour no matter whether the macro's
// WEN is a single bit or a bit-mask.
//
// Clocking - why the macros run on the FALLING edge:
//   The core is single-cycle and expects a COMBINATIONAL read (RD valid in the
//   same cycle as A). Compiled SRAMs are synchronous. Clocking them on ~clk means
//     posedge : PC updates -> fetch -> decode -> regfile -> ALU -> A/WEN/D ready
//     negedge : SRAM samples A (read) or writes D (store)
//     posedge : Q -> load unit -> write-back -> regfile captures
//   A load sees the correct word in the same instruction; a store lands mid-cycle
//   and is visible to the very next instruction, i.e. identical architectural
//   behaviour to the behavioural model. Cost: two half-cycle timing budgets.
//
// Depth: the behavioural model is 64 KB; physically this is 1 KB mirrored across
// 0x0000_0000-0x0000_FFFF (address bits [15:10] ignored). Keep test programs'
// data inside 0x000-0x3FF.
//
// !! Pin names below follow the Artisan-style lab macro (CLK, CEN, WEN, OEN, A,
// !! D, Q, all enables active-low). VERIFY with scripts/inspect_macro.sh and edit
// !! the instance port names if your .lib differs.
// =============================================================================
module data_mem #(parameter int WORDS = 16384) (   // WORDS kept for port-compat, unused
    input  logic        clk, memwrite,
    input  logic [3:0]  be,
    input  logic [31:0] A,
    input  logic [31:0] WD,
    output logic [31:0] RD
);
    logic        clk_n;
    logic [15:0] q [0:3];

    assign clk_n = ~clk;

    genvar b;
    generate
        for (b = 0; b < 4; b = b + 1) begin : g_lane
            ram_256x16A u_ram (
                .CLK (clk_n),
                .CEN (1'b0),                          // always enabled (read every cycle)
                .WEN (~(memwrite & be[b])),           // active-low write enable
                .OEN (1'b0),                          // outputs always driven
                .A   (A[9:2]),                        // word address
                .D   ({8'h00, WD[8*b +: 8]}),
                .Q   (q[b])
            );
            assign RD[8*b +: 8] = q[b][7:0];
        end
    endgenerate
endmodule
