`include "vec_defs.svh"

class vec_transaction;
    string     kind;   // "NORMAL","INVALID","BUSY_LOCK","DOUBLE_START","UNMAPPED","RESET_CHECK"
    string     name;

    int        opcode;
    int        vd, vs1, vs2;
    int        vl;
    bit [31:0] src1[4], src2[4], vd_seed[4];   // vd_seed pre-loads vd before the op (masking check)

    bit [31:0] exp_elem[4];
    bit [31:0] exp_result;
    bit        exp_err;
    bit        is_reduction;

    bit [31:0] obs_elem[4];
    bit [31:0] obs_result;
    bit        obs_busy, obs_done, obs_err;
endclass


class vec_generator;
    mailbox #(vec_transaction) gen2drv;
    int num_issued = 0;
    function new(mailbox #(vec_transaction) gen2drv); this.gen2drv = gen2drv; endfunction

    task run();
        vec_transaction t;

        // ---- RESET_CHECK ----
        t = new(); t.kind = "RESET_CHECK"; t.name = "RESET";
        gen2drv.put(t);
	num_issued++;

        // ---- ADD, full vl=4 ----
        t = new(); t.kind="NORMAL"; t.name="ADD_VL4"; t.opcode=`VOP_ADD; t.vd=2; t.vs1=0; t.vs2=1; t.vl=4;
        t.src1 = '{1,2,3,4}; t.src2 = '{10,20,30,40}; t.vd_seed = '{0,0,0,0};
        t.exp_elem = '{11,22,33,44};
        gen2drv.put(t);
	num_issued++;

        // ---- MUL, full vl=4 ----
        t = new(); t.kind="NORMAL"; t.name="MUL_VL4"; t.opcode=`VOP_MUL; t.vd=2; t.vs1=0; t.vs2=1; t.vl=4;
        t.src1 = '{2,3,4,5}; t.src2 = '{2,2,2,2}; t.vd_seed = '{0,0,0,0};
        t.exp_elem = '{4,6,8,10};
        gen2drv.put(t);
	num_issued++;

        // ---- SLT, signed corner (negative vs positive) ----
        t = new(); t.kind="NORMAL"; t.name="SLT_SIGNED"; t.opcode=`VOP_SLT; t.vd=2; t.vs1=0; t.vs2=1; t.vl=4;
        t.src1 = '{32'hFFFF_FFFF, 32'd5, 32'hFFFF_FFFF, 32'd0}; t.src2 = '{32'd1, 32'd5, 32'hFFFF_FFFE, 32'd0};
        t.vd_seed = '{0,0,0,0};
        t.exp_elem = '{1,0,0,0};
        gen2drv.put(t);
	num_issued++;

        // ---- SEQ, partial vl=2 -> lanes 2,3 must keep their seeded value (masking) ----
        t = new(); t.kind="NORMAL"; t.name="SEQ_MASKED_VL2"; t.opcode=`VOP_SEQ; t.vd=2; t.vs1=0; t.vs2=1; t.vl=2;
        t.src1 = '{7,7,99,99}; t.src2 = '{7,8,1,1}; t.vd_seed = '{32'hDEAD_0002,32'hDEAD_0003,32'hDEAD_0004,32'hDEAD_0005};
        t.exp_elem = '{1, 0, 32'hDEAD_0004, 32'hDEAD_0005};   // lanes 0,1 computed; 2,3 unchanged
        gen2drv.put(t);
	num_issued++;

        // ---- REDSUM, full vl=4 ----
        t = new(); t.kind="NORMAL"; t.name="REDSUM_VL4"; t.opcode=`VOP_REDSUM; t.vd=3; t.vs1=0; t.vs2=1; t.vl=4;
        t.src1 = '{1,2,3,4}; t.src2 = '{0,0,0,0}; t.vd_seed = '{0,0,0,0};
        t.is_reduction = 1; t.exp_result = 10;
        gen2drv.put(t);
	num_issued++;

        // ---- REDMAX, partial vl=3 (element 3 must NOT count) ----
        t = new(); t.kind="NORMAL"; t.name="REDMAX_VL3"; t.opcode=`VOP_REDMAX; t.vd=3; t.vs1=0; t.vs2=1; t.vl=3;
        t.src1 = '{5, 99, 12, 1000}; t.src2 = '{0,0,0,0}; t.vd_seed = '{0,0,0,0};
        t.is_reduction = 1; t.exp_result = 99;
        gen2drv.put(t);
	num_issued++;

        // ---- Aliased operand: vd == vs1 (in-place accumulate) ----
        t = new(); t.kind="NORMAL"; t.name="ALIASED_ADD"; t.opcode=`VOP_ADD; t.vd=0; t.vs1=0; t.vs2=1; t.vl=4;
        t.src1 = '{1,1,1,1}; t.src2 = '{9,9,9,9}; t.vd_seed = '{0,0,0,0};
        t.exp_elem = '{10,10,10,10};
        gen2drv.put(t);
	num_issued++;

        // ---- INVALID: opcode out of range ----
        t = new(); t.kind="INVALID"; t.name="INVALID_OPCODE"; t.opcode=6; t.vd=2; t.vs1=0; t.vs2=1; t.vl=4;
        t.exp_err = 1;
        gen2drv.put(t);
	num_issued++;

        // ---- INVALID: vl too large ----
        t = new(); t.kind="INVALID"; t.name="INVALID_VL_TOOBIG"; t.opcode=`VOP_ADD; t.vd=2; t.vs1=0; t.vs2=1; t.vl=5;
        t.exp_err = 1;
        gen2drv.put(t);
	num_issued++;

        // ---- INVALID: vl = 0 ----
        t = new(); t.kind="INVALID"; t.name="INVALID_VL_ZERO"; t.opcode=`VOP_ADD; t.vd=2; t.vs1=0; t.vs2=1; t.vl=0;
        t.exp_err = 1;
        gen2drv.put(t);
	num_issued++;

        // ---- config write attempted while BUSY must be ignored ----
        t = new(); t.kind="BUSY_LOCK"; t.name="BUSY_WRITE_LOCK";
        gen2drv.put(t);
	num_issued++;

        // ---- a second START issued right after the first must be ignored ----
        t = new(); t.kind="DOUBLE_START"; t.name="DOUBLE_START";
        gen2drv.put(t);
	num_issued++;

        // ---- read outside window and outside known regs -> 0 ----
        t = new(); t.kind="UNMAPPED"; t.name="UNMAPPED_READ";
        gen2drv.put(t);
	num_issued++;

    endtask
endclass


class vec_monitor;
    mailbox #(vec_transaction) mon2sb;
    vec_transaction pending;
    function new(mailbox #(vec_transaction) mon2sb); this.mon2sb = mon2sb; endfunction

    task run();
        forever begin
            @($root.vec_tb_top.txn_done);
            if (pending != null) mon2sb.put(pending);
            ->$root.vec_tb_top.sample_done;
        end
    endtask
endclass


class vec_driver;
    mailbox #(vec_transaction) gen2drv, drv2sb;
    vec_monitor mon;
    function new(mailbox #(vec_transaction) gen2drv, mailbox #(vec_transaction) drv2sb, vec_monitor mon);
        this.gen2drv = gen2drv; this.drv2sb = drv2sb; this.mon = mon;
    endfunction

    task run();
        vec_transaction t;
        forever begin
            gen2drv.get(t);
            mon.pending = t;
            execute(t);
            ->$root.vec_tb_top.txn_done;
            @($root.vec_tb_top.sample_done);
            drv2sb.put(t);
        end
    endtask

    task execute(vec_transaction t);
        bit [31:0] status;
        case (t.kind)
            "RESET_CHECK": begin
                $root.vec_tb_top.assert_reset();
                $root.vec_tb_top.release_reset();
                @(posedge $root.vec_tb_top.clk);
                $root.vec_tb_top.read_word(`VREG_STATUS, status);
                t.obs_busy = status[0]; t.obs_done = status[1]; t.obs_err = status[2];
            end

            "NORMAL", "INVALID": begin
                $root.vec_tb_top.assert_reset();
                $root.vec_tb_top.release_reset();
                for (int l = 0; l < 4; l++)
                    $root.vec_tb_top.write_word(11'h100 + t.vd*16 + l*4, t.vd_seed[l]);
                for (int l = 0; l < 4; l++) begin
                    $root.vec_tb_top.write_word(11'h100 + t.vs1*16 + l*4, t.src1[l]);
                    $root.vec_tb_top.write_word(11'h100 + t.vs2*16 + l*4, t.src2[l]);
                end
                $root.vec_tb_top.write_word(`VREG_OP, t.opcode);
                $root.vec_tb_top.write_word(`VREG_VSEL, {t.vs2[2:0], t.vs1[2:0], t.vd[2:0]});
                $root.vec_tb_top.write_word(`VREG_VL, t.vl);
                $root.vec_tb_top.write_word(`VREG_CTRL, 32'h1);
                repeat (5) begin
                    $root.vec_tb_top.read_word(`VREG_STATUS, status);
                    if (status[1]) break;
                end
                t.obs_busy = status[0]; t.obs_done = status[1]; t.obs_err = status[2];
                if (t.is_reduction)
                    $root.vec_tb_top.read_word(`VREG_RESULT, t.obs_result);
                else
                    for (int l = 0; l < 4; l++)
                        $root.vec_tb_top.read_word(11'h100 + t.vd*16 + l*4, t.obs_elem[l]);
            end

            "BUSY_LOCK": begin
                bit [31:0] op_before, op_during, op_after;
                $root.vec_tb_top.assert_reset();
                $root.vec_tb_top.release_reset();
                $root.vec_tb_top.write_word(11'h100, 32'd1); $root.vec_tb_top.write_word(11'h104, 32'd1);
                $root.vec_tb_top.write_word(`VREG_OP, `VOP_ADD);
                $root.vec_tb_top.write_word(`VREG_VSEL, {3'd0,3'd0,3'd0});
                $root.vec_tb_top.write_word(`VREG_VL, 32'd4);
                $root.vec_tb_top.read_word(`VREG_OP, op_before);
                // issue START, then attempt a config write on the VERY NEXT edge (the busy/EXEC cycle)
                @(posedge $root.vec_tb_top.clk);
                $root.vec_tb_top.vif_sel = 1; $root.vec_tb_top.vif_we = 1;
                $root.vec_tb_top.vif_addr = `VREG_CTRL; $root.vec_tb_top.vif_wdata = 32'h1;
                @(posedge $root.vec_tb_top.clk);           // START committed here; busy now 1
                $root.vec_tb_top.vif_addr = `VREG_OP; $root.vec_tb_top.vif_wdata = `VOP_MUL; // attempted while busy
                @(posedge $root.vec_tb_top.clk);           // this edge: op write should be IGNORED (still busy)
                $root.vec_tb_top.vif_we = 0; $root.vec_tb_top.vif_sel = 0;
                @(posedge $root.vec_tb_top.clk);
                $root.vec_tb_top.read_word(`VREG_OP, op_after);
                t.exp_err = 1'b0;
                t.obs_err = (op_after !== `VOP_ADD);        // fail if the busy-time write got through
            end

            "DOUBLE_START": begin
                $root.vec_tb_top.assert_reset();
                $root.vec_tb_top.release_reset();
                $root.vec_tb_top.write_word(11'h100, 32'd3);
                $root.vec_tb_top.write_word(11'h104, 32'd4);
                $root.vec_tb_top.write_word(`VREG_OP, `VOP_ADD);
                $root.vec_tb_top.write_word(`VREG_VSEL, {3'd0,3'd0,3'd0});
                $root.vec_tb_top.write_word(`VREG_VL, 32'd1);
                // Hold CTRL.START asserted continuously across two edges: the
                // edge where the first START is sampled (busy: 0->1), and the
                // very next edge, where the DUT must see this SAME still-held
                // write and reject it because busy is now 1 -- this is the
                // only way to genuinely land a write inside a 1-cycle busy
                // window; two separate write_word() calls are one clock too slow.
                @(posedge $root.vec_tb_top.clk);
                $root.vec_tb_top.vif_sel = 1; $root.vec_tb_top.vif_we = 1;
                $root.vec_tb_top.vif_addr = `VREG_CTRL; $root.vec_tb_top.vif_wdata = 32'h1;
                @(posedge $root.vec_tb_top.clk);   // 1st START sampled here: busy 0->1
                @(posedge $root.vec_tb_top.clk);   // 2nd START attempt sampled here, busy=1: must be rejected; EXEC also completes here (result=6)
                $root.vec_tb_top.vif_we = 0; $root.vec_tb_top.vif_sel = 0;
                @(posedge $root.vec_tb_top.clk);
                $root.vec_tb_top.read_word(11'h100, t.obs_elem[0]);
                t.exp_elem[0] = 6;
                t.obs_err = (t.obs_elem[0] !== 6);
            end

            "UNMAPPED": begin
                $root.vec_tb_top.assert_reset();
                $root.vec_tb_top.release_reset();
                $root.vec_tb_top.read_word(11'h020, t.obs_result);
                t.exp_result = 0;
            end
        endcase
    endtask
endclass


class vec_scoreboard;
    mailbox #(vec_transaction) drv2sb, mon2sb;
    int pass_cnt = 0, fail_cnt = 0;
    function new(mailbox #(vec_transaction) drv2sb, mailbox #(vec_transaction) mon2sb);
        this.drv2sb = drv2sb; this.mon2sb = mon2sb;
    endfunction

    task run();
        vec_transaction e, o;
        forever begin
            drv2sb.get(e); mon2sb.get(o); compare(e);
        end
    endtask

    task compare(vec_transaction t);
        bit ok = 1'b1;
        case (t.kind)
            "RESET_CHECK": if (t.obs_busy || t.obs_done || t.obs_err) ok = 0;
            "NORMAL": begin
                if (t.obs_err !== 1'b0) ok = 0;
                if (t.is_reduction) begin
                    if (t.obs_result !== t.exp_result) ok = 0;
                end else begin
                    foreach (t.exp_elem[i]) if (t.obs_elem[i] !== t.exp_elem[i]) ok = 0;
                end
            end
            "INVALID": if (t.obs_err !== t.exp_err) ok = 0;
            "BUSY_LOCK", "DOUBLE_START": if (t.obs_err !== 1'b0) ok = 0;   // obs_err here means "mismatch detected"
            "UNMAPPED": if (t.obs_result !== t.exp_result) ok = 0;
        endcase

        if (ok) begin
            pass_cnt++; $display("[%0t] PASS  %s", $time, t.name);
        end else begin
            fail_cnt++; $display("[%0t] FAIL  %s (kind=%s)", $time, t.name, t.kind);
        end
    endtask
endclass


class vec_environment;
    mailbox #(vec_transaction) gen2drv, drv2sb, mon2sb;
    vec_generator  gen;
    vec_driver     drv;
    vec_monitor    mon;
    vec_scoreboard sb;

    function new();
        gen2drv = new(); drv2sb = new(); mon2sb = new();
        gen = new(gen2drv);
        mon = new(mon2sb);
        drv = new(gen2drv, drv2sb, mon);
        sb  = new(drv2sb, mon2sb);
    endfunction

    task run();
        fork drv.run(); mon.run(); sb.run(); join_none
        gen.run();
        wait (sb.pass_cnt + sb.fail_cnt >= gen.num_issued);
        #10;
        $display("==== SUMMARY: PASS=%0d FAIL=%0d ====", sb.pass_cnt, sb.fail_cnt);
    endtask
endclass


class vec_test;
    vec_environment env;
    function new(); env = new(); endfunction
    task run(); env.run(); endtask
endclass


module vec_tb_top;
    logic clk = 0;
    always #5 clk = ~clk;
    logic rst;

    logic        vif_sel, vif_we;
    logic [10:0] vif_addr;
    logic [31:0] vif_wdata, vif_rdata;

    vec_coproc #(.LANES(4), .NVREG(8)) dut (
        .clk(clk), .rst(rst), .sel(vif_sel), .we(vif_we),
        .addr(vif_addr), .wdata(vif_wdata), .rdata(vif_rdata)
    );

    task assert_reset();
        rst = 1'b1; vif_sel = 0; vif_we = 0;
        repeat (3) @(posedge clk);
    endtask
    task release_reset();
        rst = 1'b0;
    endtask
    task write_word(input bit [10:0] a, input bit [31:0] d);
        @(posedge clk); vif_sel=1; vif_we=1; vif_addr=a; vif_wdata=d;
        @(posedge clk); vif_we=0; vif_sel=0;
    endtask
    task read_word(input bit [10:0] a, output bit [31:0] val);
        @(posedge clk); vif_sel=1; vif_we=0; vif_addr=a;
        #1; val = vif_rdata;
        @(posedge clk); vif_sel=0;
    endtask

    event txn_done;
    event sample_done;


  initial begin
    automatic vec_test t;
    rst = 1'b0; vif_sel = 0; vif_we = 0;
    t = new();
    t.run();
    $finish;
end 
endmodule