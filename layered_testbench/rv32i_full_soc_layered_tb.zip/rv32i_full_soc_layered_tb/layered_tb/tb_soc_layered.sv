`include "vec_defs.svh"

localparam OP_ITYPE  = 7'b0010011;
localparam OP_LOAD   = 7'b0000011;
localparam OP_STORE  = 7'b0100011;
localparam OP_LUI    = 7'b0110111;

function automatic bit [31:0] enc_i(bit[11:0] imm, bit[4:0] rs1, bit[2:0] f3, bit[4:0] rd, bit[6:0] op);
    return {imm,rs1,f3,rd,op};
endfunction
function automatic bit [31:0] enc_s(bit[11:0] imm, bit[4:0] rs2, bit[4:0] rs1, bit[2:0] f3, bit[6:0] op);
    return {imm[11:5],rs2,rs1,f3,imm[4:0],op};
endfunction
function automatic bit [31:0] enc_u(bit[19:0] imm20, bit[4:0] rd, bit[6:0] op);
    return {imm20,rd,op};
endfunction

class soc_transaction;
    string     name;
    bit [31:0] src1[4], src2[4];
    int        opcode;
    bit [31:0] exp_result[4];
    bit [31:0] obs_result[4];
    bit        obs_trap, obs_err;
endclass


class soc_generator;
    mailbox #(soc_transaction) gen2drv;
    int num_issued = 0;
    function new(mailbox #(soc_transaction) gen2drv); this.gen2drv = gen2drv; endfunction

    task run();
        soc_transaction t;
        t = new(); t.name = "SOC_VADD";
        t.src1 = '{1,2,3,4}; t.src2 = '{10,20,30,40}; t.opcode = `VOP_ADD;
        t.exp_result = '{11,22,33,44};
        gen2drv.put(t);
        num_issued++;

        t = new(); t.name = "SOC_VMUL";
        t.src1 = '{2,3,4,5}; t.src2 = '{5,5,5,5}; t.opcode = `VOP_MUL;
        t.exp_result = '{10,15,20,25};
        gen2drv.put(t);
        num_issued++;
    endtask
endclass


class soc_monitor;
    mailbox #(soc_transaction) mon2sb;
    soc_transaction pending;
    function new(mailbox #(soc_transaction) mon2sb); this.mon2sb = mon2sb; endfunction

    task run();
        forever begin
            @($root.soc_tb_top.program_done);
            if (pending != null) begin
                for (int i = 0; i < 4; i++)
                    pending.obs_result[i] = $root.soc_tb_top.read_reg(10+i);
                pending.obs_trap = $root.soc_tb_top.dut.trap;
                mon2sb.put(pending);
            end
            ->$root.soc_tb_top.sample_done;
        end
    endtask
endclass


class soc_driver;
    mailbox #(soc_transaction) gen2drv, drv2sb;
    soc_monitor mon;
    function new(mailbox #(soc_transaction) gen2drv, mailbox #(soc_transaction) drv2sb, soc_monitor mon);
        this.gen2drv = gen2drv; this.drv2sb = drv2sb; this.mon = mon;
    endfunction

    task run();
        soc_transaction t;
        forever begin
            gen2drv.get(t);
            mon.pending = t;
            build_and_run(t);
            ->$root.soc_tb_top.program_done;
            @($root.soc_tb_top.sample_done);
            drv2sb.put(t);
        end
    endtask

    task build_and_run(soc_transaction t);
        bit [31:0] q[$]; bit [31:0] prog[];
        int off;
        bit [4:0] rd_sel;

        // x1 = coprocessor base (0x4000_0000); v0 = window offset 0x100, v1 = 0x110
        q.push_back(enc_u(20'h40000, 5'd1, OP_LUI));
        for (int l = 0; l < 4; l++) begin
            off = 16'h100 + l*4;
            q.push_back(enc_i(t.src1[l][11:0], 5'd0, 3'b000, 5'd2, OP_ITYPE));
            q.push_back(enc_s(off[11:0], 5'd2, 5'd1, 3'b010, OP_STORE));
        end
        for (int l = 0; l < 4; l++) begin
            off = 16'h110 + l*4;
            q.push_back(enc_i(t.src2[l][11:0], 5'd0, 3'b000, 5'd2, OP_ITYPE));
            q.push_back(enc_s(off[11:0], 5'd2, 5'd1, 3'b010, OP_STORE));
        end
        q.push_back(enc_i(t.opcode[11:0], 5'd0, 3'b000, 5'd2, OP_ITYPE));
        q.push_back(enc_s(12'h004, 5'd2, 5'd1, 3'b010, OP_STORE));                 // OP
        q.push_back(enc_i(12'b001_000_000, 5'd0, 3'b000, 5'd2, OP_ITYPE));         // VSEL: vd=0,vs1=0,vs2=1(0b001)
        q.push_back(enc_s(12'h008, 5'd2, 5'd1, 3'b010, OP_STORE));
        q.push_back(enc_i(12'd4, 5'd0, 3'b000, 5'd2, OP_ITYPE));                   // VL=4
        q.push_back(enc_s(12'h00C, 5'd2, 5'd1, 3'b010, OP_STORE));
        q.push_back(enc_i(12'd1, 5'd0, 3'b000, 5'd2, OP_ITYPE));                   // CTRL.START
        q.push_back(enc_s(12'h000, 5'd2, 5'd1, 3'b010, OP_STORE));
        repeat (8) q.push_back(enc_i(12'd0,5'd0,3'b000,5'd0,OP_ITYPE));            // wait for DONE
        for (int l = 0; l < 4; l++) begin
            off = 16'h100 + l*4;
            rd_sel = 10 + l;
            q.push_back(enc_i(off[11:0], 5'd1, 3'b010, rd_sel, OP_LOAD));          // read back vd(=v0) into x10..x13
        end

        prog = new[q.size()]; foreach (q[i]) prog[i] = q[i];

        $root.soc_tb_top.assert_reset();
        $root.soc_tb_top.load_program(prog.size(), prog);
        $root.soc_tb_top.release_reset();
        $root.soc_tb_top.run_cycles(prog.size() + 5);
    endtask
endclass


class soc_scoreboard;
    mailbox #(soc_transaction) drv2sb, mon2sb;
    int pass_cnt = 0, fail_cnt = 0;
    function new(mailbox #(soc_transaction) drv2sb, mailbox #(soc_transaction) mon2sb);
        this.drv2sb = drv2sb; this.mon2sb = mon2sb;
    endfunction

    task run();
        soc_transaction e, o;
        forever begin drv2sb.get(e); mon2sb.get(o); compare(e); end
    endtask

    task compare(soc_transaction t);
        bit ok = ~t.obs_trap;
        foreach (t.exp_result[i]) if (t.obs_result[i] !== t.exp_result[i]) ok = 1'b0;

        if (ok) begin
            pass_cnt++; $display("[%0t] PASS  %s", $time, t.name);
        end else begin
            fail_cnt++; $display("[%0t] FAIL  %s trap=%0b", $time, t.name, t.obs_trap);
            foreach (t.exp_result[i])
                $display("        result[%0d] exp=%0d obs=%0d", i, t.exp_result[i], t.obs_result[i]);
        end
    endtask
endclass


class soc_environment;
    mailbox #(soc_transaction) gen2drv, drv2sb, mon2sb;
    soc_generator  gen;
    soc_driver     drv;
    soc_monitor    mon;
    soc_scoreboard sb;

    function new();
        gen2drv = new(); drv2sb = new(); mon2sb = new();
        gen = new(gen2drv);
        mon = new(mon2sb);
        drv = new(gen2drv, drv2sb, mon);
        sb  = new(drv2sb, mon2sb);
    endfunction

    task run();
        fork drv.run(); mon.run(); sb.run(); join_none
        gen.run();
        wait (sb.pass_cnt + sb.fail_cnt >= gen.num_issued);
        #10;
        $display("==== SUMMARY: PASS=%0d FAIL=%0d ====", sb.pass_cnt, sb.fail_cnt);
    endtask
endclass


class soc_test;
    soc_environment env;
    function new(); env = new(); endfunction
    task run(); env.run(); endtask
endclass


module soc_tb_top;
    logic clk = 0;
    always #5 clk = ~clk;
    logic rst;

    riscv_soc_top dut (.clk(clk), .rst(rst), .trap(), .halted(), .trap_cause(), .rvfi());

    task assert_reset();
        rst = 1'b1;
        repeat (3) @(posedge clk);
    endtask
    task release_reset();
        rst = 1'b0;
    endtask
    task load_program(input int n, input bit [31:0] prog[]);
        int a;
        for (int i = 0; i < n; i++) begin
            a = i*4;
            dut.ins_mem2.mem[a]   = prog[i][7:0];
            dut.ins_mem2.mem[a+1] = prog[i][15:8];
            dut.ins_mem2.mem[a+2] = prog[i][23:16];
            dut.ins_mem2.mem[a+3] = prog[i][31:24];
        end
    endtask
    task run_cycles(input int n);
        repeat (n) @(posedge clk);
    endtask
    function automatic bit [31:0] read_reg(input int idx);
        return dut.u_core.reg_file4.regfile[idx];
    endfunction

    event program_done;
    event sample_done;

    initial begin
    automatic soc_test t;
    rst = 1'b0;
    t = new();
    t.run();
    $finish;
    end
endmodule