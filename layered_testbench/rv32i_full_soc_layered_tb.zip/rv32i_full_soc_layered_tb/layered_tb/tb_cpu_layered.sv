`include "rv32i_types.svh"

localparam OP_RTYPE  = 7'b0110011;
localparam OP_ITYPE  = 7'b0010011;
localparam OP_LOAD   = 7'b0000011;
localparam OP_STORE  = 7'b0100011;
localparam OP_BRANCH = 7'b1100011;
localparam OP_JAL    = 7'b1101111;
localparam OP_JALR   = 7'b1100111;
localparam OP_LUI    = 7'b0110111;
localparam OP_AUIPC  = 7'b0010111;

localparam bit [31:0] ECALL_INSTR   = 32'h0000_0073;
localparam bit [31:0] EBREAK_INSTR  = 32'h0010_0073;
localparam bit [31:0] ILLEGAL_INSTR = 32'hFFFF_FFFF;

function automatic bit [31:0] enc_r(bit[6:0] f7,bit[4:0] rs2,bit[4:0] rs1,bit[2:0] f3,bit[4:0] rd,bit[6:0] op);
    return {f7,rs2,rs1,f3,rd,op};
endfunction
function automatic bit [31:0] enc_i(bit[11:0] imm,bit[4:0] rs1,bit[2:0] f3,bit[4:0] rd,bit[6:0] op);
    return {imm,rs1,f3,rd,op};
endfunction
function automatic bit [31:0] enc_s(bit[11:0] imm,bit[4:0] rs2,bit[4:0] rs1,bit[2:0] f3,bit[6:0] op);
    return {imm[11:5],rs2,rs1,f3,imm[4:0],op};
endfunction
function automatic bit [31:0] enc_b(bit[12:0] imm,bit[4:0] rs2,bit[4:0] rs1,bit[2:0] f3,bit[6:0] op);
    return {imm[12],imm[10:5],rs2,rs1,f3,imm[4:1],imm[11],op};
endfunction
function automatic bit [31:0] enc_j(bit[20:0] imm,bit[4:0] rd,bit[6:0] op);
    return {imm[20],imm[10:1],imm[11],imm[19:12],rd,op};
endfunction
function automatic bit [31:0] enc_u(bit[19:0] imm20,bit[4:0] rd,bit[6:0] op);
    return {imm20,rd,op};
endfunction


class cpu_transaction;
    string     name;
    bit [31:0] prog[];
    int        run_cycles;

    int        exp_reg_idx[$];
    bit [31:0] exp_reg_val[$];
    bit [31:0] obs_reg_val[$];

    bit        expect_trap;
    bit [4:0]  exp_cause;
    bit [4:0]  obs_cause;
    bit        obs_halted;
endclass


class cpu_generator;
    mailbox #(cpu_transaction) gen2drv;
    int num_issued = 0;
    function new(mailbox #(cpu_transaction) gen2drv); this.gen2drv = gen2drv; endfunction

    task run();
        cpu_transaction t;

        // ---- ALU_LOGIC: add/sub/and/or/xor/sll ----
        t = new(); t.name = "ALU_LOGIC";
        t.prog = '{
            enc_i(12'd7,5'd0,3'b000,5'd1,OP_ITYPE), enc_i(12'd3,5'd0,3'b000,5'd2,OP_ITYPE),
            enc_r(7'b0000000,5'd2,5'd1,3'b000,5'd3,OP_RTYPE), enc_r(7'b0100000,5'd2,5'd1,3'b000,5'd4,OP_RTYPE),
            enc_r(7'b0000000,5'd2,5'd1,3'b111,5'd5,OP_RTYPE), enc_r(7'b0000000,5'd2,5'd1,3'b110,5'd6,OP_RTYPE),
            enc_r(7'b0000000,5'd2,5'd1,3'b100,5'd7,OP_RTYPE), enc_r(7'b0000000,5'd2,5'd1,3'b001,5'd8,OP_RTYPE)
        };
        t.run_cycles = 8;
        t.exp_reg_idx = '{1,2,3,4,5,6,7,8};
        t.exp_reg_val = '{32'd7,32'd3,32'd10,32'd4,32'd3,32'd7,32'd4,32'd56};
        gen2drv.put(t);
	num_issued++;

        // ---- ALU_SHIFT_RIGHT: srl vs sra on a negative value ----
        t = new(); t.name = "ALU_SHIFT_RIGHT";
        t.prog = '{
            enc_i(12'(-8),5'd0,3'b000,5'd1,OP_ITYPE), enc_i(12'd3,5'd0,3'b000,5'd2,OP_ITYPE),
            enc_r(7'b0000000,5'd2,5'd1,3'b101,5'd3,OP_RTYPE), enc_r(7'b0100000,5'd2,5'd1,3'b101,5'd4,OP_RTYPE)
        };
        t.run_cycles = 4;
        t.exp_reg_idx = '{3,4};
        t.exp_reg_val = '{32'h1FFF_FFFF, 32'hFFFF_FFFF};
        gen2drv.put(t);
	num_issued++;

        // ---- ALU_COMPARE: slt (signed) vs sltu (unsigned) ----
        t = new(); t.name = "ALU_COMPARE";
        t.prog = '{
            enc_i(12'(-1),5'd0,3'b000,5'd1,OP_ITYPE), enc_i(12'd1,5'd0,3'b000,5'd2,OP_ITYPE),
            enc_r(7'b0000000,5'd2,5'd1,3'b010,5'd3,OP_RTYPE), enc_r(7'b0000000,5'd2,5'd1,3'b011,5'd4,OP_RTYPE)
        };
        t.run_cycles = 4;
        t.exp_reg_idx = '{3,4};
        t.exp_reg_val = '{32'd1, 32'd0};
        gen2drv.put(t);
	num_issued++;

        // ---- BEQ_TAKEN ----
        t = new(); t.name = "BEQ_TAKEN";
        t.prog = '{
            enc_i(12'd5,5'd0,3'b000,5'd1,OP_ITYPE), enc_i(12'd5,5'd0,3'b000,5'd2,OP_ITYPE),
            enc_b(13'd8,5'd2,5'd1,3'b000,OP_BRANCH),
            enc_i(12'd99,5'd0,3'b000,5'd3,OP_ITYPE), enc_i(12'd1,5'd0,3'b000,5'd4,OP_ITYPE)
        };
        t.run_cycles = 4;
        t.exp_reg_idx = '{1,2,3,4};
        t.exp_reg_val = '{32'd5,32'd5,32'd0,32'd1};
        gen2drv.put(t);
	num_issued++;

        // ---- JAL ----
        t = new(); t.name = "JAL";
        t.prog = '{
            enc_j(21'd8,5'd5,OP_JAL),
            enc_i(12'd99,5'd0,3'b000,5'd6,OP_ITYPE), enc_i(12'd42,5'd0,3'b000,5'd7,OP_ITYPE)
        };
        t.run_cycles = 2;
        t.exp_reg_idx = '{5,6,7};
        t.exp_reg_val = '{32'd4,32'd0,32'd42};
        gen2drv.put(t);
	num_issued++;

        // ---- JALR ----
        t = new(); t.name = "JALR";
        t.prog = '{
            enc_i(12'd12,5'd0,3'b000,5'd8,OP_ITYPE),
            enc_i(12'd0,5'd8,3'b000,5'd9,OP_JALR),
            enc_i(12'd99,5'd0,3'b000,5'd10,OP_ITYPE), enc_i(12'd55,5'd0,3'b000,5'd11,OP_ITYPE)
        };
        t.run_cycles = 3;
        t.exp_reg_idx = '{8,9,10,11};
        t.exp_reg_val = '{32'd12,32'd8,32'd0,32'd55};
        gen2drv.put(t);
	num_issued++;

        // ---- MEM_OPS: byte/half/word, signed + unsigned loads ----
        t = new(); t.name = "MEM_OPS";
        t.prog = '{
            enc_i(12'd100,5'd0,3'b000,5'd1,OP_ITYPE),
            enc_i(12'(-1),5'd0,3'b000,5'd2,OP_ITYPE), enc_s(12'd0,5'd2,5'd1,3'b000,OP_STORE),
            enc_i(12'd0,5'd1,3'b000,5'd3,OP_LOAD), enc_i(12'd0,5'd1,3'b100,5'd4,OP_LOAD),
            enc_i(12'(-2),5'd0,3'b000,5'd5,OP_ITYPE), enc_s(12'd4,5'd5,5'd1,3'b001,OP_STORE),
            enc_i(12'd4,5'd1,3'b001,5'd6,OP_LOAD), enc_i(12'd4,5'd1,3'b101,5'd7,OP_LOAD),
            enc_i(12'(-123),5'd0,3'b000,5'd8,OP_ITYPE), enc_s(12'd8,5'd8,5'd1,3'b010,OP_STORE),
            enc_i(12'd8,5'd1,3'b010,5'd9,OP_LOAD)
        };
        t.run_cycles = 12;
        t.exp_reg_idx = '{3,4,6,7,9};
        t.exp_reg_val = '{32'hFFFF_FFFF,32'd255,32'hFFFF_FFFE,32'd65534,32'hFFFF_FF85};
        gen2drv.put(t);
	num_issued++;

        // ---- UPPER_IMM: lui + auipc ----
        t = new(); t.name = "UPPER_IMM";
        t.prog = '{
            enc_u(20'hABCDE,5'd1,OP_LUI), enc_u(20'h2,5'd2,OP_AUIPC)
        };
        t.run_cycles = 2;
        t.exp_reg_idx = '{1,2};
        t.exp_reg_val = '{32'hABCD_E000, 32'h0000_2004};
        gen2drv.put(t);
	num_issued++;

        // ---- one directed transaction per unique trap cause ----
        t = new(); t.name = "TRAP_ILLEGAL";       t.prog = '{ILLEGAL_INSTR};  t.run_cycles=1; t.expect_trap=1; t.exp_cause=`RV_CAUSE_ILLEGAL;          gen2drv.put(t);
        t = new(); t.name = "TRAP_EBREAK";        t.prog = '{EBREAK_INSTR};  t.run_cycles=1; t.expect_trap=1; t.exp_cause=`RV_CAUSE_EBREAK;           gen2drv.put(t);
        t = new(); t.name = "TRAP_ECALL";         t.prog = '{ECALL_INSTR};   t.run_cycles=1; t.expect_trap=1; t.exp_cause=`RV_CAUSE_ECALL;            gen2drv.put(t);

        t = new(); t.name = "TRAP_LOAD_MISALIGNED";
        t.prog = '{ enc_i(12'd1,5'd0,3'b000,5'd1,OP_ITYPE), enc_i(12'd0,5'd1,3'b010,5'd2,OP_LOAD) };
        t.run_cycles = 2; t.expect_trap = 1; t.exp_cause = `RV_CAUSE_LOAD_MISALIGNED;
        gen2drv.put(t);
	num_issued++;

        t = new(); t.name = "TRAP_STORE_MISALIGNED";
        t.prog = '{ enc_i(12'd1,5'd0,3'b000,5'd1,OP_ITYPE), enc_i(12'd5,5'd0,3'b000,5'd2,OP_ITYPE), enc_s(12'd0,5'd2,5'd1,3'b010,OP_STORE) };
        t.run_cycles = 3; t.expect_trap = 1; t.exp_cause = `RV_CAUSE_STORE_MISALIGNED;
        gen2drv.put(t);
	num_issued++;

        t = new(); t.name = "TRAP_FETCH_MISALIGNED";
        t.prog = '{ enc_i(12'd2,5'd0,3'b000,5'd1,OP_ITYPE), enc_i(12'd0,5'd1,3'b000,5'd2,OP_JALR) };
        t.run_cycles = 2; t.expect_trap = 1; t.exp_cause = `RV_CAUSE_FETCH_MISALIGNED;
        gen2drv.put(t);
	num_issued++;
    endtask
endclass


class cpu_monitor;
    mailbox #(cpu_transaction) mon2sb;
    cpu_transaction pending;
    function new(mailbox #(cpu_transaction) mon2sb); this.mon2sb = mon2sb; endfunction

    task run();
        forever begin
            @($root.cpu_tb_top.program_done);
            if (pending != null) begin
                pending.obs_reg_val.delete();
                foreach (pending.exp_reg_idx[i])
                    pending.obs_reg_val.push_back($root.cpu_tb_top.read_reg(pending.exp_reg_idx[i]));
                pending.obs_halted = $root.cpu_tb_top.dut.halted;
                pending.obs_cause  = $root.cpu_tb_top.dut.trap_cause;
                mon2sb.put(pending);
            end
            ->$root.cpu_tb_top.sample_done;
        end
    endtask
endclass


class cpu_driver;
    mailbox #(cpu_transaction) gen2drv;
    mailbox #(cpu_transaction) drv2sb;
    cpu_monitor mon;

    function new(mailbox #(cpu_transaction) gen2drv, mailbox #(cpu_transaction) drv2sb, cpu_monitor mon);
        this.gen2drv = gen2drv; this.drv2sb = drv2sb; this.mon = mon;
    endfunction

    task run();
        cpu_transaction t;
        forever begin
            gen2drv.get(t);
            mon.pending = t;
            $root.cpu_tb_top.assert_reset();
            $root.cpu_tb_top.clear_regs();
            $root.cpu_tb_top.load_program(t.prog.size(), t.prog);
            $root.cpu_tb_top.release_reset();
            $root.cpu_tb_top.run_cycles(t.run_cycles + 2);   // +2 margin for trap latch
            ->$root.cpu_tb_top.program_done;
            @($root.cpu_tb_top.sample_done);
            drv2sb.put(t);
        end
    endtask
endclass


class cpu_scoreboard;
    mailbox #(cpu_transaction) drv2sb, mon2sb;
    int pass_cnt = 0, fail_cnt = 0;
    function new(mailbox #(cpu_transaction) drv2sb, mailbox #(cpu_transaction) mon2sb);
        this.drv2sb = drv2sb; this.mon2sb = mon2sb;
    endfunction

    task run();
        cpu_transaction e, o;
        forever begin
            drv2sb.get(e); mon2sb.get(o); compare(e);
        end
    endtask

    task compare(cpu_transaction t);
        bit ok = 1'b1;
        if (t.expect_trap) begin
            if (!t.obs_halted) ok = 1'b0;
            if (t.obs_cause !== t.exp_cause) ok = 1'b0;
        end else begin
            foreach (t.exp_reg_idx[i])
                if (t.obs_reg_val[i] !== t.exp_reg_val[i]) ok = 1'b0;
        end

        if (ok) begin
            pass_cnt++; $display("[%0t] PASS  %s", $time, t.name);
        end else begin
            fail_cnt++; $display("[%0t] FAIL  %s", $time, t.name);
            if (t.expect_trap)
                $display("        halted=%0b exp_cause=%0d obs_cause=%0d", t.obs_halted, t.exp_cause, t.obs_cause);
            else
                foreach (t.exp_reg_idx[i])
                    $display("        x%0d exp=%0h obs=%0h", t.exp_reg_idx[i], t.exp_reg_val[i], t.obs_reg_val[i]);
        end
    endtask
endclass


class cpu_environment;
    mailbox #(cpu_transaction) gen2drv, drv2sb, mon2sb;
    cpu_generator  gen;
    cpu_driver     drv;
    cpu_monitor    mon;
    cpu_scoreboard sb;

    function new();
        gen2drv = new(); drv2sb = new(); mon2sb = new();
        gen = new(gen2drv);
        mon = new(mon2sb);
        drv = new(gen2drv, drv2sb, mon);
        sb  = new(drv2sb, mon2sb);
    endfunction

    task run();
        fork drv.run(); mon.run(); sb.run(); join_none
        gen.run();
        wait (sb.pass_cnt + sb.fail_cnt >= gen.num_issued);
        #10;
        $display("==== SUMMARY: PASS=%0d FAIL=%0d ====", sb.pass_cnt, sb.fail_cnt);
    endtask
endclass


class cpu_test;
    cpu_environment env;
    function new(); env = new(); endfunction
    task run(); env.run(); endtask
endclass


module cpu_tb_top;
    logic clk = 0;
    always #5 clk = ~clk;
    logic rst;

    sgle_cyc_processor dut (.clk(clk), .rst(rst),
        .trap(), .halted(), .trap_cause(), .rvfi());

    task assert_reset();
        rst = 1'b1;
        repeat (3) @(posedge clk);
    endtask
    task release_reset();
        rst = 1'b0;
    endtask
    task clear_regs();
        for (int i = 1; i < 32; i++) dut.u_core.reg_file4.regfile[i] = 32'd0;
    endtask
    task load_program(input int n, input bit [31:0] prog[]);
        int a;
        for (int i = 0; i < n; i++) begin
            a = i*4;
            dut.ins_mem2.mem[a]   = prog[i][7:0];
            dut.ins_mem2.mem[a+1] = prog[i][15:8];
            dut.ins_mem2.mem[a+2] = prog[i][23:16];
            dut.ins_mem2.mem[a+3] = prog[i][31:24];
        end
    endtask
    task run_cycles(input int n);
        repeat (n) @(posedge clk);
    endtask
    function automatic bit [31:0] read_reg(input int idx);
        return dut.u_core.reg_file4.regfile[idx];
    endfunction

    event program_done;
    event sample_done;


initial begin
    automatic cpu_test t;
    rst = 1'b0;
    t = new();
    t.run();
    $finish;
end
endmodule